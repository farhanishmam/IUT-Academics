// Define the interface for the strategy pattern
interface QuackBehavior {
    void quack();
}
