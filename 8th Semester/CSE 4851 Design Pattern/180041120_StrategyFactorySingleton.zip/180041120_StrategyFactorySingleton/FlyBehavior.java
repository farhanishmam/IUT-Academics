// Define the interface for the strategy pattern
interface FlyBehavior {
    void fly();
}