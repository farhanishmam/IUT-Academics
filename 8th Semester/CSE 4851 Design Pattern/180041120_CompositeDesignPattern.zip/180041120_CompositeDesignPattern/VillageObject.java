//Component Interface
public interface VillageObject {
    void draw();
}